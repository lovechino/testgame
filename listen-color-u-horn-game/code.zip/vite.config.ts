import { defineConfig } from 'vite';

export default defineConfig({
    server: {
        open: true, // tự động mở browser
    },
});
