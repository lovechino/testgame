// src/consts/Keys.ts

// 1. Tên các Màn chơi (Scene)
export enum SceneKeys {
    Preload = 'PreloadScene',
    Scene1 = 'Scene1',
    Scene2 = 'Scene2',
    EndGame = 'EndGameScene'
}

// 2. Tên các Hình ảnh (Texture)
export enum TextureKeys {
    // --- UI Dùng Chung ---
    BtnExit = 'btn_exit',
    BtnReset = 'btn_reset',
    BtnEraser = 'btn_eraser',
    HandHint = 'hand_hint',
    BgPopup = 'bg_popup', // board_pop_up dùng chung

    // --- Scene 1 (Cái Ô) ---
    S1_BannerBg = 'banner_bg_s1',
    S1_BannerText = 'banner_text_s1',
    S1_Board = 'board_white',
    S1_PoemText = 'poem_text',
    S1_Rain = 'img_rain',
    S1_IconOHeader = 'icon_o_header',
    S1_ItemUmbrella = 'item_umbrella',
    S1_ItemMushroom = 'item_mushroom',
    S1_ItemLamp = 'item_lamp',
    S1_TextResult = 'text_result_s1',

    // --- Scene 2 (Tô Màu) ---
    S2_Banner = 'banner_s2',
    S2_TextBanner = 'text_banner_s2',
    S2_Board = 'board_s2',

    // Các bộ phận tô màu
    S2_O_Outline = 'o_outline',
    S2_O_Hat = 'o_hat',
    S2_O_Body = 'o_body',

    S2_Co_Outline = 'co_outline',
    S2_Co_Face = 'co_face',
    S2_Co_Hair = 'co_hair',
    S2_Co_Shirt = 'co_shirt',
    S2_Co_HandL = 'co_hand_l',
    S2_Co_HandR = 'co_hand_r',
    S2_Co_Book = 'co_book',

    // Các nút màu
    BtnRed = 'btn_red',
    BtnYellow = 'btn_yellow',
    BtnGreen = 'btn_green',
    BtnBlue = 'btn_blue',
    BtnPurple = 'btn_purple',
    BtnCream = 'btn_cream',
    BtnBlack = 'btn_black',

    // --- End Game ---
    End_Icon = 'icon_end',
    End_BannerCongrat = 'banner_congrat',
    // 3. Tên Âm thanh (Audio)
    S1_Player = "S1_Player",
    S1_soccer = "S1_soccer",
    S1_enginer = "S1_enginer",
    S1_doctor = "S1_doctor",
    S2_goal = "S2_goal",
    S2_rectangle = "s2_rectangle",
    S2_player = "S2_player",
    S2_text = "S2_text",
    S2_vector = "S2_vector",
    S2_vector2 = "S2_vector2",
    S2_vector3 = "S2_vector3",
    S2_vector4 = "S2_vector4",
    S2_vector5 = "S2_vector5",
    S2_vector6 = "S2_vector6",
    S2_vector7 = "S2_vector7",
    S2_vector9 = "S2_vector9",
    S2_vector8 = "S2_vector8",
    S2_text_relust = "S2_text_relust",
    S2_U_Outline = "u_outline",
    S2_ball = "S2_ball",
    S2_text_scene2 = "S2_text_scene2",
}

// 3. Tên Âm thanh (Audio)
export enum AudioKeys {
    BgmNen = 'bgm-nen'
}

// 4. Tên File Data (JSON)
export enum DataKeys {
    LevelS2Config = 'level_config'
}
